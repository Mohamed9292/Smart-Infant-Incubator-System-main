﻿global using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
global using Microsoft.EntityFrameworkCore.Metadata.Builders;
global using Microsoft.AspNetCore.Identity;
global using Microsoft.EntityFrameworkCore;
global using InfraStructure.Configuration;
global using InfraStructure.Interfaces;