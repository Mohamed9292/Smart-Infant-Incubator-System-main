﻿namespace IncubatorApi.Services.IOTService;

public class cryAnalysis
{
    public double hungry { get; set; }
    public double belly_pain { get; set; }
    public double burping { get; set; }
    public double discomfort { get; set; }
    public double tired { get; set; }
}