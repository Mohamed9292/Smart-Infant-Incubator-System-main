﻿namespace IncubatorApi.IOTService
{
    public enum ControlTypes
    {
        TEMP = 1,
        MOTOR = 2,
        LAMP = 3,
        MIC = 4,

    }
}
