﻿namespace InfraStructure.Interfaces;

public interface IMapperProfile
{
    
}