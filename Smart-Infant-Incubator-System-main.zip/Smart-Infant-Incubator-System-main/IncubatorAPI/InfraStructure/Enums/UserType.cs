﻿namespace InfraStructure.Enums;

public enum UserType
{
    None,
    Admin,
    Operator,
    Doctor,
    Nurse,
    Mother
}