﻿global using System.ComponentModel.DataAnnotations;
global using DataAccess.Entities;
global using InfraStructure.Interfaces;