# Smart-Infant-Incubator-System
ASP.NET Core API
